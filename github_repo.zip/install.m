function install()
    addpath('code');
    addpath('tests');
end