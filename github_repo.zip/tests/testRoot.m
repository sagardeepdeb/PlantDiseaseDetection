function path = testRoot()
    
    % Copyright 2020 The MathWorks, Inc.
    path = fileparts(mfilename('fullpath'));
end