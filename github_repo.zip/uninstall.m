function uninstall()
    rmpath('code');
    rmpath('tests');
end